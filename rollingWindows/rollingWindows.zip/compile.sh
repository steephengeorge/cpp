g++ -std=c++17 -Wall -O2 -pedantic *.cpp -o rollingWindows
